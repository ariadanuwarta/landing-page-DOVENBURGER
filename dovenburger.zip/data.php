<?php
/**
 * data.php - Sumber data tunggal DOVEN BURGER.
 *
 * Dipakai oleh index.php (tampilan), proses.php (pesanan), lacak.php dan admin.php.
 * Menu, harga, add-on, dan promo cukup diubah DI SINI. Harga selalu dihitung ulang
 * di server dari data ini, jadi tidak bisa dipalsukan dari browser.
 */

declare(strict_types=1);

date_default_timezone_set('Asia/Jakarta');

/* ---------- Pengaturan toko ---------- */
const WA_TOKO       = '6281234567890'; // format internasional tanpa tanda +
const ONGKIR_FLAT   = 10000;           // biaya antar (delivery)
const GRATIS_ONGKIR = 120000;          // belanja minimal agar ongkir gratis
const JAM_BUKA      = 10;              // jam buka (WIB)
const JAM_TUTUP     = 22;              // jam tutup (WIB)
const MAKS_BARIS    = 15;              // maksimal jenis item per pesanan
const MAKS_QTY      = 20;              // maksimal jumlah per item
const JADWAL_MIN_MENIT = 30;           // pesanan terjadwal minimal sekian menit dari sekarang

// Info pembayaran yang tampil ke pelanggan setelah memesan. GANTI dengan data toko Anda.
const REKENING = ['bank' => 'BCA', 'nomor' => '1234567890', 'nama' => 'DOVEN BURGER'];
// Untuk QRIS: simpan gambar QR toko sebagai assets/qris.png (atau .webp / .jpg). Opsional.

const TIPE_PESANAN   = ['dine-in' => 'Makan di tempat', 'takeaway' => 'Bawa pulang', 'delivery' => 'Antar ke alamat'];
const METODE_BAYAR   = ['tunai' => 'Tunai', 'qris' => 'QRIS', 'transfer' => 'Transfer bank'];
const STATUS_PESANAN = ['baru' => 'Diterima', 'diproses' => 'Diproses', 'siap' => 'Siap', 'selesai' => 'Selesai', 'batal' => 'Dibatalkan'];

/* ---------- Menu ---------- */
function dataMenu(): array
{
    return [
        'free-throw' => [
            'tersedia' => true, // ubah ke false bila stok habis; menu tampil Habis dan tidak bisa dipesan
            'nama' => 'Free Throw Burger', 'kategori' => 'burger', 'ikon' => '🍔', 'tag' => 'Klasik',
            'foto' => 'free-throw', 'warna' => '#fbbf24', 'addon' => true,
            'desc' => 'Single smash patty 100% premium beef, cheddar leleh, selada renyah, saus rahasia DOVEN di atas brioche panggang mentega.',
            'bahan' => ['Beef 90 gr', 'Cheddar', 'Selada', 'Saus DOVEN'],
            'harga' => ['Single' => 38000, 'Double' => 52000, 'Combo' => 68000],
            'svg' => ['patties' => 1, 'bacon' => false],
        ],
        'layup' => [
            'tersedia' => true, // ubah ke false bila stok habis; menu tampil Habis dan tidak bisa dipesan
            'nama' => 'Layup Burger', 'kategori' => 'burger', 'ikon' => '🍔', 'tag' => 'Terlaris',
            'foto' => 'layup', 'warna' => '#f97316', 'addon' => true,
            'desc' => 'Double patty juicy, keju cheddar, bacon crispy, tomat segar, dan saus smoky. Gurih, tebal, dan bikin nagih.',
            'bahan' => ['Beef 2x90 gr', 'Bacon', 'Tomat', 'Saus smoky'],
            'harga' => ['Single' => 48000, 'Double' => 64000, 'Combo' => 82000],
            'svg' => ['patties' => 2, 'bacon' => true],
        ],
        'hook-shot' => [
            'tersedia' => true, // ubah ke false bila stok habis; menu tampil Habis dan tidak bisa dipesan
            'nama' => 'Hook Shot Burger', 'kategori' => 'burger', 'ikon' => '🍔', 'tag' => 'Signature',
            'foto' => 'hook-shot', 'warna' => '#ef4444', 'addon' => true,
            'desc' => 'Edisi signature dengan triple patty wagyu-blend, triple cheese, bacon, truffle mayo, dan brioche hitam arang.',
            'bahan' => ['Wagyu-blend', 'Triple cheese', 'Truffle mayo', 'Bacon'],
            'harga' => ['Single' => 58000, 'Double' => 76000, 'Combo' => 96000],
            'svg' => ['patties' => 3, 'bacon' => true, 'bunL' => '#6b7280', 'bunD' => '#111827'],
        ],
        'fries' => [
            'tersedia' => true, // ubah ke false bila stok habis; menu tampil Habis dan tidak bisa dipesan
            'nama' => 'Crispy Fries', 'kategori' => 'pendamping', 'ikon' => '🍟', 'tag' => 'Favorit',
            'foto' => 'fries', 'warna' => '#f59e0b', 'addon' => false,
            'desc' => 'Kentang goreng renyah berbumbu garam laut, disajikan panas. Teman paling setia untuk burger apa pun.',
            'bahan' => ['Kentang premium', 'Garam laut', 'Goreng sesaat'],
            'harga' => ['Reguler' => 22000, 'Large' => 30000],
            'svg' => null,
        ],
        'shake' => [
            'tersedia' => true, // ubah ke false bila stok habis; menu tampil Habis dan tidak bisa dipesan
            'nama' => 'Choco Milkshake', 'kategori' => 'pendamping', 'ikon' => '🥤', 'tag' => 'Dingin',
            'foto' => 'milkshake', 'warna' => '#b45309', 'addon' => false,
            'desc' => 'Milkshake cokelat kental dengan whipped cream dan taburan cokelat. Dingin, manis, pas untuk menyeimbangkan gurihnya burger.',
            'bahan' => ['Cokelat', 'Susu segar', 'Whipped cream'],
            'harga' => ['Reguler' => 28000, 'Large' => 36000],
            'svg' => null,
        ],
        'sauce' => [
            'tersedia' => true, // ubah ke false bila stok habis; menu tampil Habis dan tidak bisa dipesan
            'nama' => 'Saus Rahasia DOVEN', 'kategori' => 'pendamping', 'ikon' => '🥫', 'tag' => 'Rahasia',
            'foto' => 'sauce', 'warna' => '#ef4444', 'addon' => false,
            'desc' => 'Saus rumahan yang diracik setiap pagi: creamy, smoky, dan sedikit pedas. Cocok untuk cocolan kentang.',
            'bahan' => ['Creamy', 'Smoky', 'Sedikit pedas'],
            'harga' => ['Reguler' => 5000, 'Large' => 9000],
            'svg' => null,
        ],
    ];
}

/* ---------- Tambahan (khusus menu dengan 'addon' => true) ---------- */
function dataAddon(): array
{
    return [
        'extra-cheese' => ['nama' => 'Extra Cheddar',     'harga' => 6000],
        'extra-bacon'  => ['nama' => 'Extra Bacon',       'harga' => 9000],
        'extra-patty'  => ['nama' => 'Extra Patty',       'harga' => 18000],
        'jalapeno'     => ['nama' => 'Jalapeño',          'harga' => 4000],
        'extra-saus'   => ['nama' => 'Saus DOVEN Extra',  'harga' => 3000],
    ];
}

/* ---------- Kode promo ---------- */
function dataPromo(): array
{
    return [
        'DOVEN10'      => ['label' => 'Diskon 10% (maks. Rp 20.000)', 'jenis' => 'persen',  'nilai' => 10,    'maks' => 20000, 'min' => 50000],
        'GAMEDAY'      => ['label' => 'Potongan Rp 15.000',           'jenis' => 'nominal', 'nilai' => 15000, 'maks' => 15000, 'min' => 90000],
        'GRATISONGKIR' => ['label' => 'Gratis ongkir (delivery)',     'jenis' => 'ongkir',  'nilai' => 0,     'maks' => 0,     'min' => 60000],
    ];
}

/* ---------- Helper umum ---------- */
function rupiah(int $angka): string
{
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

function e(string $teks): string
{
    return htmlspecialchars($teks, ENT_QUOTES, 'UTF-8');
}

/** Ambil nilai skalar sebagai string; selain itu jadi string kosong (cegah "Array to string"). */
function teks(mixed $nilai): string
{
    return is_scalar($nilai) ? (string)$nilai : '';
}

function jsonBalas(bool $sukses, string $pesan, array $tambahan = [], int $kode = 200)
{
    http_response_code($kode);
    echo json_encode(array_merge(['sukses' => $sukses, 'pesan' => $pesan], $tambahan), JSON_UNESCAPED_UNICODE);
    exit;
}

/** Ubah +62 / 62 / 08 menjadi 08xxxxxxxxxx. Kembalikan '' jika tidak valid. */
function normalisasiWa(string $nomor): string
{
    $wa = preg_replace('/[\s\-\(\)\.]/', '', $nomor) ?? '';
    $wa = preg_replace('/^\+?62/', '0', $wa) ?? '';
    return preg_match('/^08[0-9]{8,12}$/', $wa) === 1 ? $wa : '';
}

/** "20 Okt 2026, 14.05 WIB" dari timestamp MySQL. */
function tanggalIndo(string $timestamp): string
{
    $bulan = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    $t = strtotime($timestamp) ?: time();
    return date('j', $t) . ' ' . $bulan[(int)date('n', $t)] . ' ' . date('Y, H.i', $t) . ' WIB';
}

function tokoBuka(): bool
{
    $jam = (int)date('G');
    return $jam >= JAM_BUKA && $jam < JAM_TUTUP;
}

/* ---------- Pesanan terjadwal ---------- */

/**
 * Daftar waktu yang boleh dipilih (hari ini & besok, kelipatan 30 menit dalam jam buka,
 * paling cepat JADWAL_MIN_MENIT dari sekarang). Server adalah sumber kebenaran.
 * @return array<int,array{nilai:string,label:string}>
 */
function slotJadwal(?DateTimeImmutable $sekarang = null): array
{
    $sekarang ??= new DateTimeImmutable('now');
    $batas = $sekarang->modify('+' . JADWAL_MIN_MENIT . ' minutes');
    $namaHari = ['Hari ini', 'Besok'];
    $slot = [];
    for ($d = 0; $d < 2; $d++) {
        $tgl = $sekarang->setTime(0, 0)->modify('+' . $d . ' day');
        for ($m = JAM_BUKA * 60; $m <= JAM_TUTUP * 60 - 30; $m += 30) {
            $t = $tgl->setTime(intdiv($m, 60), $m % 60);
            if ($t < $batas) {
                continue;
            }
            $slot[] = ['nilai' => $t->format('Y-m-d H:i'), 'label' => $namaHari[$d] . ', ' . $t->format('H.i')];
        }
    }
    return $slot;
}

/** Kembalikan waktu bila termasuk slot yang sah; selain itu null. */
function validasiJadwal(string $nilai): ?string
{
    foreach (slotJadwal() as $s) {
        if ($s['nilai'] === $nilai) {
            return $nilai;
        }
    }
    return null;
}

/** "Hari ini, 14.30" / "Besok, 10.00" / "22 Okt, 10.00" dari timestamp MySQL. */
function labelJadwal(string $timestamp): string
{
    $t = strtotime($timestamp);
    if ($t === false) {
        return '';
    }
    $bulan = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    $hari = date('Y-m-d', $t);
    if ($hari === date('Y-m-d')) {
        $awal = 'Hari ini';
    } elseif ($hari === date('Y-m-d', strtotime('+1 day'))) {
        $awal = 'Besok';
    } else {
        $awal = date('j', $t) . ' ' . $bulan[(int)date('n', $t)];
    }
    return $awal . ', ' . date('H.i', $t);
}

/* ---------- Pembayaran ---------- */

/** Gambar QRIS toko bila ada di assets/. */
function pathQris(): ?string
{
    foreach (['png', 'webp', 'jpg', 'jpeg'] as $ext) {
        $rel = 'assets/qris.' . $ext;
        if (is_file(__DIR__ . '/' . $rel)) {
            return $rel . '?v=' . filemtime(__DIR__ . '/' . $rel);
        }
    }
    return null;
}

/** Petunjuk pembayaran untuk layar sukses (null untuk tunai). */
function infoBayar(string $metode, int $total): ?array
{
    if ($metode === 'transfer') {
        return ['jenis' => 'transfer', 'bank' => REKENING['bank'], 'nomor' => REKENING['nomor'], 'nama' => REKENING['nama'], 'total' => $total];
    }
    if ($metode === 'qris') {
        return ['jenis' => 'qris', 'gambar' => pathQris(), 'total' => $total];
    }
    return null;
}

/* ---------- Perhitungan harga (SELALU dijalankan di server) ---------- */

/**
 * Validasi keranjang hasil json_decode lalu hitung harga tiap baris.
 * @return array{error:string}|array{baris:array<int,array<string,mixed>>,subtotal:int}
 */
function hitungKeranjang(mixed $mentah): array
{
    $menu  = dataMenu();
    $addon = dataAddon();

    if (!is_array($mentah) || $mentah === [] || array_keys($mentah) !== range(0, count($mentah) - 1)) {
        return ['error' => 'Keranjang masih kosong.'];
    }
    if (count($mentah) > MAKS_BARIS) {
        return ['error' => 'Maksimal ' . MAKS_BARIS . ' jenis item per pesanan.'];
    }

    $baris = [];
    $subtotal = 0;
    foreach ($mentah as $r) {
        if (!is_array($r)) {
            return ['error' => 'Data keranjang tidak valid.'];
        }
        $id     = teks($r['id'] ?? '');
        $varian = teks($r['varian'] ?? '');
        $qty    = (int)teks($r['qty'] ?? 0);

        if (!isset($menu[$id]) || !isset($menu[$id]['harga'][$varian])) {
            return ['error' => 'Ada menu yang tidak valid. Muat ulang halaman lalu coba lagi.'];
        }
        if (($menu[$id]['tersedia'] ?? true) === false) {
            return ['error' => $menu[$id]['nama'] . ' sedang habis. Hapus dari keranjang lalu coba lagi.'];
        }
        if ($qty < 1 || $qty > MAKS_QTY) {
            return ['error' => 'Jumlah per item harus antara 1 dan ' . MAKS_QTY . '.'];
        }

        $dipilih = is_array($r['addons'] ?? null) ? array_values(array_unique(array_filter($r['addons'], 'is_string'))) : [];
        $namaAddon = [];
        $hargaAddon = 0;
        foreach ($dipilih as $a) {
            if (!$menu[$id]['addon'] || !isset($addon[$a])) {
                return ['error' => 'Tambahan yang dipilih tidak valid.'];
            }
            $namaAddon[] = $addon[$a]['nama'];
            $hargaAddon += $addon[$a]['harga'];
        }

        $catatan = mb_substr(trim(teks($r['catatan'] ?? '')), 0, 120);
        $satuan  = (int)$menu[$id]['harga'][$varian] + $hargaAddon;
        $sub     = $satuan * $qty;
        $subtotal += $sub;

        $baris[] = [
            'id' => $id, 'nama' => $menu[$id]['nama'], 'varian' => $varian, 'qty' => $qty,
            'addons' => $namaAddon, 'catatan' => $catatan, 'satuan' => $satuan, 'subtotal' => $sub,
        ];
    }

    return ['baris' => $baris, 'subtotal' => $subtotal];
}

/** @return array{ok:bool,pesan:string,kode:string,diskon:int,gratis_ongkir:bool} */
function hitungPromo(string $kode, int $subtotal): array
{
    $kode = strtoupper(trim($kode));
    $gagal = static fn(string $pesan): array => ['ok' => false, 'pesan' => $pesan, 'kode' => '', 'diskon' => 0, 'gratis_ongkir' => false];

    if ($kode === '') {
        return $gagal('Masukkan kode promo terlebih dahulu.');
    }
    $daftar = dataPromo();
    if (!isset($daftar[$kode])) {
        return $gagal('Kode promo tidak ditemukan.');
    }
    $p = $daftar[$kode];
    if ($subtotal < $p['min']) {
        return $gagal('Kode ' . $kode . ' berlaku untuk belanja minimal ' . rupiah($p['min']) . '.');
    }

    $diskon = 0;
    if ($p['jenis'] === 'persen') {
        $diskon = min((int)floor($subtotal * $p['nilai'] / 100), $p['maks']);
    } elseif ($p['jenis'] === 'nominal') {
        $diskon = min($p['nilai'], $subtotal);
    }

    return ['ok' => true, 'pesan' => 'Kode ' . $kode . ' dipakai: ' . $p['label'] . '.', 'kode' => $kode, 'diskon' => $diskon, 'gratis_ongkir' => $p['jenis'] === 'ongkir'];
}

/** @return array{subtotal:int,diskon:int,ongkir:int,total:int} */
function hitungTotal(int $subtotal, string $tipe, ?array $promo): array
{
    $diskon = (int)($promo['diskon'] ?? 0);
    $ongkir = 0;
    if ($tipe === 'delivery') {
        $gratis = $subtotal >= GRATIS_ONGKIR || !empty($promo['gratis_ongkir']);
        $ongkir = $gratis ? 0 : ONGKIR_FLAT;
    }
    return ['subtotal' => $subtotal, 'diskon' => $diskon, 'ongkir' => $ongkir, 'total' => max(0, $subtotal - $diskon + $ongkir)];
}
